import { Component, OnInit } from '@angular/core';
import { Product } from '../product'
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  /*Creating Object of Product*/ 
  products: Product[];

  /*Initialising values in constructor*/
  constructor() {

    this.products = [
      {
        id: 1,
        title: "Mobile",
        description: "Color:Black",
        sales_price: 10000,
        current_stock:20


      },
      {
        id: 2,
        title: "MobileCharger",
        description: "Color:Black",
        sales_price: 500,
        current_stock: 30

      },
      {
        id: 3,
        title: "EarPhones",
        description: "Color:Red",
        sales_price: 700,
        current_stock: 15
      },
      {
        id: 4,
        title: "PowerBank",
        description: "Color:Silver",
        sales_price: 1500,
        current_stock: 5

      },
      {
        id: 5,
        title: "Mobile Cover",
        description: "Color:Multiple colors",
        sales_price: 400,
        current_stock: 50

      }
      
    ]
  }
  

  ngOnInit(): void {
  }

}
