﻿//Practice Example 3
// C# program to find factorial
// of given number
using System;

namespace factorial
{
	
	class Program
	{
		// method to find factorial
		// of given number
		static int factorial(int n)
		{
			
			if (n == 0)
				return 1;

			return n * factorial(n - 1);
		}

		// main  method
		public static void Main()
		{
			Console.Write("enter any positive whole number for factorial :");
			try
			{
				int givenumber = int.Parse(Console.ReadLine());
				// contition check for negative number 
				if (givenumber < 0)
				{
					Console.WriteLine("Negative number is invalid , please enter positive number");

				}
				else
				{
					Console.WriteLine("Factorial of " + givenumber + " is " + factorial(givenumber));
				}
			}
			// exception handling for invald formet
			catch (FormatException ex1)
			{
				Console.WriteLine(ex1.Message);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
            }
		}
	}

	

}
