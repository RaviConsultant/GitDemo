﻿// Practice example 5
//Write a program to print mathematical table of given number till 12.
using System;

namespace mathematical_table
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, tempVarible = 0;
            Console.Write("Please enter a number (only a positive whole number): ");
            try
            {
                int userInput = int.Parse(Console.ReadLine());
                // condition check for negative  number
                if (userInput < 0)
                {
                    Console.WriteLine("Please enter positive number");
                }
                else
                    // loop for print table
                    for (i = 1; i <= 12; i++)
                    {
                        tempVarible = userInput * i;
                        Console.WriteLine(i + " * " + userInput + " = " + tempVarible);
                    }
            }
            // exception handling for invald formet
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
