﻿////Practice Example 1

//<summarv>
///// Calculating sum of digits
// </summary>
//<param name= "givenumber"></param>
//<returns></returns:

using System;
public class sumofinteger
{
    public static void Main(string[] args)
    {
        // "givenumber" is a number which imput provide bt user
        int givenumber, sumofdigit = 0, tempvarible, flag=0;
        try
        {
            // input from user 
            Console.Write("Please enter a number (only a positive whole number): ");
            givenumber = int.Parse(Console.ReadLine());
            while (givenumber > 0)
            {
                flag++;
                tempvarible = givenumber % 10;
                sumofdigit = sumofdigit + tempvarible;
                givenumber = givenumber / 10;
            }
            // print the sum of digit after check condition
            if (flag != 0)
            {
                Console.Write("Sum is= " + sumofdigit);
            }
            // while loop for check given number is positive
            while (flag == 0 && givenumber < 0)
            {
                Console.WriteLine("Please enter a number (only a positive whole number): "); 
                break;
            }

        }
        // if the user give the imput in different formet
        catch (FormatException ex1)
        {
               Console.WriteLine(ex1.Message);
        }
    }
}