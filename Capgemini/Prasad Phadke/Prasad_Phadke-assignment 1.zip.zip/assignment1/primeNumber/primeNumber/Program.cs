﻿using System;

namespace PrimeNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1=2,num2;
            Boolean flag = true; 
            num2=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Prime numbers between "+ num1 + " and " + num2);
            for (int i = num1; i <= num2; i++)
            {
                //  loop the iterations for i times
                for (int j = 2; j < i; j++)
                {
                    if ((i % j) == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag == true)
                {
                    Console.WriteLine(i);
                }
                flag = true;
            }
        }
        }
    }

