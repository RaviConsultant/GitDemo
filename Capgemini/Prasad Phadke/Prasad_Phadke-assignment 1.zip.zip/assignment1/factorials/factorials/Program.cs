﻿using System;

namespace factorials
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j = 1, num;
            Console.Write("enter the number : ");
            num = Convert.ToInt32(Console.ReadLine());
            for (i = 1; i <= num; i++)
                j = j * i;
            Console.WriteLine(j);
            
        }
    }
}
