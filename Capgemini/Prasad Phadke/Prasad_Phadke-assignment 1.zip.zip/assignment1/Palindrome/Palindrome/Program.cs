﻿using System;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            String inpstring, revstring=string.Empty;
            Console.WriteLine("Enter the string:-");
            inpstring = Console.ReadLine();
            if (inpstring != null)
            {
                for (int i = inpstring.Length - 1; i >= 0; i--)
                {
                    revstring += inpstring[i].ToString();
                }
                if (revstring == inpstring)
                {
                    Console.WriteLine("yes");
                }
                else
                {
                    Console.WriteLine("no");
                }
            }
           
        }
    }
}
