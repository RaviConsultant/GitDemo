﻿using System;

namespace mathTable
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("enter the number:-"); //enter your number
            int n=Convert.ToInt32(Console.ReadLine());//converting it to the int type
            for (i = 1; i <= 12; i++)
            {
                Console.WriteLine(i+"*"+"n"+"="+i*n); //output
            }
            
        }
    }
}
