﻿using System;

namespace Commission
{
    class Program
    {
        static public void overallQuatertlyCommission(int month1Sale, int month2Sale, int month3Sale)
        {
            int totalQuaterlySales = month1Sale + month2Sale + month3Sale;
            float quatertlyCommission = 0;
            float minCommission = 0;
            float totalQuatertlyCommission;

            if (totalQuaterlySales >= 10000)
            {
                quatertlyCommission = totalQuaterlySales * 12 / 100;
            }
            else if (totalQuaterlySales >= 5000 && totalQuaterlySales < 10000)
            {
                quatertlyCommission = totalQuaterlySales * 10 / 100;
            }
            else if (totalQuaterlySales >= 1000 && totalQuaterlySales < 5000)
            {
                quatertlyCommission = totalQuaterlySales * 5 / 100;
            }
            else
            {
                quatertlyCommission = 0;
            }

            if (month1Sale >= 5000 && month2Sale >= 5000 && month3Sale >= 5000)
            {
                minCommission = totalQuaterlySales * 3 / 100;
            }
            totalQuatertlyCommission = quatertlyCommission + minCommission;

            Console.WriteLine("Total Sale for the Quarter: " + totalQuaterlySales + " USD");
            Console.WriteLine("Quarterly_Commission: " + quatertlyCommission + " USD");
            Console.WriteLine("Minimum_Commission: " + minCommission + " USD");
            Console.WriteLine("Overall Commission for the Quarter: " + totalQuatertlyCommission + " USD");

        }

        static void Main(string[] args)
        {
            int month1Sales, month2Sales, month3Sales;
            Console.WriteLine("Month1 Sales in USD:");
            month1Sales = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Month2 Sales in USD:");
            month2Sales = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Month3 Sales in USD:");
            month3Sales = Convert.ToInt32(Console.ReadLine());
            overallQuatertlyCommission(month1Sales, month2Sales, month3Sales);

            Console.WriteLine("Hello World!");
        }
    }
}
