﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sumOfnos = 0;
            int integerInput = 0;
            string read;
            bool validate = true;
            #region Validation
            while (validate)
            {
                Console.WriteLine("Enter a Number to find the sum of its numbers");
                read = Console.ReadLine();                             
                var isNumber = int.TryParse(read, out integerInput);   
                if (isNumber)                                                       
                {
                    validate = false;                                             
                    if (integerInput < 0)
                        validate = true;                                          
                }
            }
            try
            {
                while (integerInput > 0)
                {
                    sumOfnos = sumOfnos + (integerInput % 10);                  
                    integerInput = integerInput / 10;                                  

                }
            }
            catch (Exception ex)
            { Console.WriteLine("An error occured please contact Admin"); }
            #endregion

            Console.WriteLine("The sum of inegers in the given number is {0} .", sumOfnos);
        }
    }
}
