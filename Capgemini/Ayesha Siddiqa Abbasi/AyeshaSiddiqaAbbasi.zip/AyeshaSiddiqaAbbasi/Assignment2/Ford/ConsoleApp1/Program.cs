﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int totalsales;
            double quaterlyCommision= 0.0D;
            double monthlysales = 0.0D;
            double overallcommision = 0.0D;
            Console.Write("1st Month Sales");
            int month1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("2nd Month Sales");
            int month2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Third Month Sales");
            int month3 = Convert.ToInt32(Console.ReadLine());
            totalsales = month1 + month2 + month3;
            Console.Write("\n Quarterly total sales ={0}\n", totalsales);

            if (totalsales > 50000)
            {
                quaterlyCommision = (totalsales * 0.05);
            }
            else if (totalsales > 30000 && totalsales < 50000)
            {
                quaterlyCommision = (totalsales * 0.045D);
                    }
            else if (totalsales > 20000 && totalsales < 30000)
            { quaterlyCommision = (totalsales * 0.0375);
            }
            else if (totalsales > 15000 && totalsales < 20000)
            {
                quaterlyCommision = (totalsales * 0.025);
            }
            else if (totalsales > 10000 && totalsales < 15000)
            {
                quaterlyCommision = (totalsales * 0.0175);
            }
            else if (totalsales < 10000)
            { quaterlyCommision = 0.0D;
            }
            if(month1>7500 && month2>7500 && month3>7500)
                {
                monthlysales = totalsales * 0.0125;

            }
            else if (month1>12500 && month2>12500 && month3>12500)
                {
                monthlysales = totalsales * 0.025;
            }

            overallcommision = quaterlyCommision + monthlysales;
            Console.Write("\n Quarterly sales commision ={0}\n", quaterlyCommision);
            Console.Write("\n Monthly minimum sales commission ={0}\n", monthlysales);
            Console.Write("\n Overall Commision for the Quarter = {0}\n",overallcommision);
            Console.ReadLine();





        }
    }
}
