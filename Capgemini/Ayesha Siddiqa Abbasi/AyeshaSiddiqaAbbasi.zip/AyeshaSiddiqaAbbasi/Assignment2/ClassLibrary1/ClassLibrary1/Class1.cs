﻿using System;

namespace Utility_opps_2_1
{
    public class Contact
    {
        public uint phone = 896541255;
        public uint mobile = 8588785522;
        public String email = "xyx@gmail.com";
    }
    public class Address
    {
        public String street = "Street";
        public String city = "lko";
        public String area = "gomti";
        public int zip = 856485;
    }
    public class Customer
    {
        Address addre;
        Contact contact;

        public void Address()
        {
            Console.WriteLine();
            Console.WriteLine("City:- " + addre.city);
            Console.WriteLine("Street:- " + addre.street);
            Console.WriteLine("Area:- " + addre.area);
            Console.WriteLine("Zip:- " + addre.zip);
        }
        public void contachinfo()
        {
            Console.WriteLine();
            Console.WriteLine("Phone:- " + contact.phone);
            Console.WriteLine("Mobile:- " + contact.mobile);
            Console.WriteLine("Email:- " + contact.email);
        }
        public void First_Name()
        {
            string first = "Ayesha";
            Console.WriteLine("Your first name is " + first);

        }
        public void Last_name()
        {
            string last = "Abbasi";
            Console.WriteLine("Your first name is " + last);
        }
    }
    public class Branch : Customer
    {

        public string Name = "Ayesha Abbasi";



    }
    public class sb_account
    {
        //Account account = new Account();

        public void withdraw(int num, int limit)
        {
            if (num > limit)
            {
                Console.WriteLine($"Sorry for your inconvinience but our acc limit is {limit}");
            }
            else
            {
                //account.currentbalance = account.currentbalance - num;
                Console.WriteLine($"{num} has been deducted from your acc...");
            }
        }
    }
    public class FD_account
    {
        //public int current = 1000;
        //Account account = new Account();
        public void deposit(int num)
        {
            //account.currentbalance = account.currentbalance + num;
            Console.WriteLine($"{num} USD has been deposited");
        }
    }
    public class RD_account
    {
        //Account account = new Account();
        //public int current = 1000;
        public void deposit(int num)
        {
            //account.currentbalance = account.currentbalance + num;
            Console.WriteLine($"{num} USD has been deposited");
        }
    }
    public class cr_account
    {
        //public int current = 1000;
        //Account account = new Account();
        public void deposit(int num)
        {
            //account.currentbalance = account.currentbalance + num;
            Console.WriteLine($"{num} USD has been deposited");
        }
        public void withdraw(int num, int limit)
        {
            if (num > limit)
            {
                Console.WriteLine($"Sorry for your inconvinience but our acc limit is {limit}");
            }
            else
            {
                //account.currentbalance = account.currentbalance + num;
                Console.WriteLine($"{num} has been deducted from your acc...");
            }
        }
    }


}
