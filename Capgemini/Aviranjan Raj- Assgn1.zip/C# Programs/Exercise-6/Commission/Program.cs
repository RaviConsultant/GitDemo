﻿using System;

namespace Commission
{
    internal class Program//Class
    {
        int Total, QuarterComm, MiniComm;
        private void TotalQuarterSale(int Month1Sale,int Month2Sale,int Month3Sale)// Total Commission method
        {
            
            Total = Month1Sale + Month2Sale + Month3Sale;

            Console.WriteLine("Total Sale for the Quarter: " + Total);
        }
        private int Quarterly_Commission()// for Quarterly Commission
        {
            int QuarterComm;
            if (Total > 20000)
            {
                QuarterComm = Total * 12 / 100;
            }
            else if(Total >= 15000 && Total < 20000)
            {
                QuarterComm = Total * 10 / 100;
            }
            else if(Total >= 10000 && Total < 15000)
            {
                QuarterComm = Total * 5 / 100;
            }
            else
            {
                QuarterComm = 0;
            }
            return QuarterComm;
        }
        private int Minimum_Commission(int Month1Sale, int Month2Sale, int Month3Sale) // finding Minimum Commission
        {
            if (Month1Sale >= 5000 && Month2Sale >= 5000 && Month3Sale >= 5000)
            {
                int MiniComm = Total * 3 / 100;
                return MiniComm;
            }
            else
            {
                MiniComm = 0;
                return MiniComm;
            }
        }

        static void Main(string[] args) // Main method
        {
            int Month1Sale;
            Console.Write("1st month sale: ");
            Month1Sale = int.Parse(Console.ReadLine());

            int Month2Sale;
            Console.Write("2nd month sale: ");
            Month2Sale = int.Parse(Console.ReadLine());

            int Month3Sale;
            Console.Write("3rd month sale: ");
            Month3Sale = int.Parse(Console.ReadLine());

            Program com = new Program();
            com.TotalQuarterSale( Month1Sale,Month2Sale,Month3Sale);
            Console.WriteLine("Quarterly Commission: " + com.Quarterly_Commission());
            Console.WriteLine("Minimum Commission: "+com.Minimum_Commission(Month1Sale, Month2Sale, Month3Sale));
            int overall_comission = com.Minimum_Commission(Month1Sale, Month2Sale, Month3Sale) + com.Quarterly_Commission();
            Console.WriteLine("Overall Commission for the Quarter: "+overall_comission);
        }
    }
}
