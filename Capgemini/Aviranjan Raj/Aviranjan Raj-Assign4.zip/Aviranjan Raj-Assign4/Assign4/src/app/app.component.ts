import { Component } from '@angular/core';

@Component({
 // selector: 'app-product-list',
 selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Assignment2';
}
