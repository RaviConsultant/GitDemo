﻿using System;
// Program to print prime numbers under the given numbers
namespace Assignment3
{
    internal class Assignment3
    {
        static void Main(string[] args)
        {
            int prime_num_upto = 0;//Input number
            int counter=1;
            int temp,i;
            bool validation = true;

            // validation of the input
            while (validation)
            {
                string readInput;
                Console.WriteLine("Enter the number");
                readInput = Console.ReadLine();
                var isvalid=int.TryParse(readInput, out prime_num_upto);
                if(isvalid)
                {
                    validation = false;
                    if (prime_num_upto < 0)
                    {
                        validation=true;
                    }
                }
            }

            
            
            Console.WriteLine("The prime numbers under {0} are", prime_num_upto);
            while(counter < prime_num_upto)
            {
                counter++;
                temp = 0;
                for(i=2;i<=(counter/2);i++)
                {
                    if(counter%i==0)
                    {
                        temp = 1;
                        break;
                    }
                }
                if(temp==0)
                {
                    Console.Write("{0} , ",counter);
                    
                }
            }
        
        }
    }
}
