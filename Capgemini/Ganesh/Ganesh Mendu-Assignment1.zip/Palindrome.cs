﻿using System;
namespace question3
{
    class Palindrome
    {
        private string initialstring;

        public string Initialstring { get; set;}  //sets the value to initialstring



        /// <summary>
        /// method checks whether the string is palindrome or not
        /// </summary>
        /// <param name="initialstring"></param>
        /// <returns></returns>
        static string IsPalindrome(string initialstring)
        {
            string reversed = "";
            foreach (char c in initialstring)
            {
                reversed = c + reversed;
            }
            if (initialstring.Equals(reversed))
            {
                return "yes";
            }
            return "no";
        }

        static void Main()
        {
            Palindrome p = new Palindrome();
            p.initialstring = Console.ReadLine();
            Console.WriteLine(IsPalindrome(p.initialstring));
        }
    }
}
