﻿using System;
namespace question6
{
    class SalesExecutive
    {
        int month1Sales;
        int month2Sales;
        int month3Sales;
        int totalSales;
        double totalSalesComm;
        double quarterlySalesComm;
        double monthlyMinSalesComm;

        public SalesExecutive(int month1Sales, int month2Sales, int month3Sales)
        {
            this.month1Sales = month1Sales;
            this.month2Sales = month2Sales;
            this.month3Sales = month3Sales;
            this.totalSales = month1Sales + month2Sales + month3Sales;
        }

        public double GetTotalSalesComm()
        {
            return totalSalesComm;
        }

        public void SetMonthlyMinSalesComm(double comm)
        {
            monthlyMinSalesComm = comm;
        }

        public double GetMonthlySalesComm()
        {
            return monthlyMinSalesComm;
        }

        public void SetQuarterlySalesComm(double comm)
        {
            quarterlySalesComm = comm;
        }

        public double GetQuarterlySalesComm()
        {
            return quarterlySalesComm;
        }

        public Boolean IsMonthlyMin()
        {
            if(month1Sales>=5000 && month2Sales>=5000 && month3Sales>=5000)
                return true;
            return false;
        }

        double CalcMonthlyMinSalesComm()
        {
            if(IsMonthlyMin())
            {
                return totalSales * 0.03;
            } else
            {
                return 0;
            }
        }

        double CalcQuarterlySalesCommission()
        {
            if (totalSales >= 20000)
            {
                return (12 * totalSales) / 100;
            }
            else if (totalSales >= 15000 && totalSales < 20000)
            {
                return (10 * totalSales) / 100;
            }
            else if (totalSales >= 10000 && totalSales < 15000)
            {
                return (5 * totalSales) / 100;
            }
            else
            {
                return 0;
            }
        }

        public void CalculateSalesComm()
        {
            SetMonthlyMinSalesComm(CalcMonthlyMinSalesComm());
            SetQuarterlySalesComm(CalcQuarterlySalesCommission());
            totalSalesComm = GetMonthlySalesComm() + GetQuarterlySalesComm();
        }

    }
    class Question6
    {
        static void Main()
        {
            SalesExecutive s1 = new SalesExecutive(6000, 5500, 7000);
            s1.CalculateSalesComm();
            Console.WriteLine(
                    "\nTotal Monthly Min Sales Comm: " + s1.GetMonthlySalesComm()+
                    "\nTotal Quarterly Sales Comm: " + s1.GetQuarterlySalesComm()+
                    "\nTotal Sales Comm: " + s1.GetTotalSalesComm()
                );
        }
    }
}
