﻿using System;
namespace question5
{
    internal class Prime
    {
        /// <summary>
        /// method to print primenumbers less than the number
        /// </summary>
        /// <param name="number"></param>
        public static void PrintPrime(ref int number)
        {
            //Console.WriteLine(number);
            for (int i = 2; i <= number; i++)
            {
                bool flag = true;
                for (int j = 2; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag == true)
                {
                    Console.Write(i+",");
                }
            }
        }
        /// <summary>
        /// function to read the value of number
        /// </summary>
        /// <param name="number"></param>
        public static void setvalue(ref int number)
        {
            Console.Write("Enter a number:");
            number = int.Parse(Console.ReadLine());
        }

        static void Main()
        {
            int number = 0;
            setvalue(ref number);
            PrintPrime(ref number);
        }
    }
    
}
