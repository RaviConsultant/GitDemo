﻿using System;

namespace Assignment6
{
    internal class Assignment6
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Assignment 6\n\n");
                int month_1_Sales, month_2_Sales, month_3_Sales, total_Quater_Sales, monthly_Comission = 0, quaterly_Comission = 0;
                int i = 1;
                Assignment6 assignment6 = new Assignment6();
                month_1_Sales = assignment6.validate(i);
                month_2_Sales = assignment6.validate(++i);
                month_3_Sales = assignment6.validate(++i);

                total_Quater_Sales = month_1_Sales + month_2_Sales + month_3_Sales;
                // Using business rules these values are assigned for reference check problem statment
                if (total_Quater_Sales < 10000)
                {
                    quaterly_Comission = 0;

                }
                else if (total_Quater_Sales < 15000)
                {
                    quaterly_Comission = total_Quater_Sales * 5 / 100;
                }
                else if (total_Quater_Sales < 20000)
                {
                    quaterly_Comission = total_Quater_Sales * 10 / 100;
                }
                else if (total_Quater_Sales >= 20000)
                {
                    quaterly_Comission = total_Quater_Sales * 12 / 100;
                }

                // Monthly comission business rules for reference chek problem statment
                if (month_1_Sales >= 5000 && month_2_Sales >= 5000 && month_3_Sales >= 5000)
                {
                    monthly_Comission = total_Quater_Sales * 3 / 100;

                }


                Console.Clear();
                Console.WriteLine("Total sales for quater \t\t\t= {0}", total_Quater_Sales);
                Console.WriteLine("Quaterly Comission \t\t\t= {0}", quaterly_Comission);
                Console.WriteLine("Minnimum Comission \t\t\t= {0}", monthly_Comission);
                Console.WriteLine("Overall Comission for the quater \t= {0}", quaterly_Comission + monthly_Comission);/* total comisiion is quaterly_
                                                                                                                  * Comission + monthly_
                                                                                                                  * Comission  */
            }
            catch (Exception ex)
            {
                Console.WriteLine("Encounterd an unexpected error please contact admin");
            }
        }


        // validation function for validating the input is a positive number
        int validate(int i)
        {
            string readInput;
            int intiger = 0;
            bool validate = true;
            while (validate)
            {
                Console.WriteLine("Enter the sales income of {0} month",i);
                readInput = Console.ReadLine();
                var isNumber=int.TryParse(readInput, out intiger);
                if (isNumber)
                {
                    validate = false;
                    if(intiger<0)
                    {
                        validate=true;
                    }
                }
            }


            return intiger;
        }
    }
}
