﻿using System;
// Program to print prime numbers under the given numbers
namespace Assignment3
{
    internal class Assignment3
    {
        static void Main(string[] args)
        {
            try
            {
                int prime_num_upto = 0;//Input number
                int counter = 1;
                int temp, i;
                bool validation = true;

                // validation of the input
                while (validation)
                {
                    string readInput;
                    Console.WriteLine("Enter the number");
                    readInput = Console.ReadLine();
                    var isvalid = int.TryParse(readInput, out prime_num_upto);
                    if (isvalid)
                    {
                        validation = false;
                        if (prime_num_upto < 0)
                        {
                            validation = true;
                        }
                    }
                }



                Console.WriteLine("The prime numbers under {0} are", prime_num_upto);
                while (counter < prime_num_upto)
                {
                    counter++;// taking numbers from 1 to the given number is assigned one after another into the counter variable
                    temp = 0;

                    //checking if the counter vaariable is prime number or not
                    for (i = 2; i <= (counter / 2); i++)
                    {
                        if (counter % i == 0)
                        {
                            temp = 1;
                            break;
                        }
                    }
                    if (temp == 0)
                    {
                        Console.Write("{0} , ", counter);

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An unexpected error occured please contact admin");
            }
        
        }
    }
}
