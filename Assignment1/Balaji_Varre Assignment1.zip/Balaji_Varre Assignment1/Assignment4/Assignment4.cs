﻿using System;
// program to check if given number is a palindroe or not
namespace Assignment4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string stringInput;
            int stringLength;

            try
            {
                Console.WriteLine("Enter a string");
                stringInput = Console.ReadLine();// reading input string
                stringLength = stringInput.Length;// Finding length of the string

                int counter = 0;// Initializing a counter with value 0 
                for (int i = 1; i <= stringLength / 2; i++)
                {

                    if (stringInput[i - 1] != stringInput[stringLength - i])
                    {
                        Console.WriteLine("{0} is not a palindrome", stringInput);
                        counter = 1;
                        break;
                    }

                }
                if (counter == 0)// only if the counter value is zero the string is a palindrome
                {
                    Console.WriteLine("{0} is a palindrome", stringInput);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Ecountered an unexpected error please contact admin");
            }
        }
    }
}
