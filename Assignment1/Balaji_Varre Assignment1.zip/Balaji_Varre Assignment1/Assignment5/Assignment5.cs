﻿using System;
// Multiplication table upto 12
namespace Assignment5
{
    internal class Assignment5
    {
        static void Main(string[] args)
        {
            int intigerInput=0;

            bool validation = true;
            int i;
            try
            {
                while (validation)
                {
                    string readInput;
                    Console.WriteLine("Enter the number");
                    readInput = Console.ReadLine();
                    var isvalid = int.TryParse(readInput, out intigerInput);
                    if (isvalid)
                    {
                        validation = false;
                        if (intigerInput < 0)
                        {
                            validation = true;
                        }
                    }

                }
                Console.Clear();//Clearing the console
                for (i = 1; i <= 12; i++)
                {
                    Console.WriteLine("{0}\t*\t{1}\t=\t{2}", i, intigerInput, i * intigerInput);//i*intigerInput gives product
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Encounterd an unexpected error please contact admin");
            }
        }
    }
}
