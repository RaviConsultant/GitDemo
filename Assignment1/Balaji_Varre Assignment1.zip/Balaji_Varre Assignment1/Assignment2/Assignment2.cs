﻿using System;

namespace Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int intigerInput = 0;
                double factorial = 0;/* Double is used here because factorial of numbers is increasing exponnentially at a very high rate
                             * and we need to accomidate the program for factorial of numbers above 16 also and int cannt be used 
                             * hereafter to store the factorial of the number*/
                string readInput;
                bool validation = true;
                //checking if the input is valid or not , if not valid the user is prompted again to enter input
                #region Validation
                while (validation)
                {
                    Console.WriteLine("Enter the number");
                    readInput = Console.ReadLine();
                    var isnumber = int.TryParse(readInput, out intigerInput);
                    if (isnumber)
                    {
                        validation = false;

                        if (intigerInput < 0)
                        {
                            validation = true;
                        }
                        if (intigerInput > 0)
                        {
                            factorial = 1;
                        }
                    }
                }
                #endregion
                //caluclatin the factorial of the number
                #region Factorial
                while (intigerInput > 1)//if intiger input is equals to one the factorial is no longer needed to be caluclated
                {
                    factorial = factorial * (intigerInput);
                    intigerInput = intigerInput - 1;
                }
                #endregion

                Console.WriteLine("Factorial of given number is {0}", factorial);//Printing of the factorial
            }
            catch (Exception ex)
            {
                Console.WriteLine("An unexpected error occured contact admin");
            }
        }
    }
}
