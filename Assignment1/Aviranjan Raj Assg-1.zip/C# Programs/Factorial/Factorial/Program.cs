﻿
using System;

namespace Factorial
{
    internal class Program
    {
        //Method for finding factorial
        private void NumFactorial()
        {
            int num, i, factorial=1;
            Console.Write("Enter a Number: ");
            num = int.Parse(Console.ReadLine());

            for (i = num-1; i >= 1; i--)
            {
                factorial = num*i;
                Console.WriteLine("Factorial of Number: " + factorial);
            }
            
        }
        // Main Method 
        public static void Main()
        {
            Program fact = new Program();
            fact.NumFactorial();
        }
    }
}
