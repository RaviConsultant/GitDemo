﻿using System;

namespace SumofDigit
{

    internal class Program
    {
        private int Sumdigit(int num) //User defined function
        {
            int sumOfdigit = 0;
            int M;
            while (num > 0)
            {
                M = num % 10;
                sumOfdigit = sumOfdigit + M;
                num = num / 10;
            }
            return sumOfdigit;
        }
        public static void Main(string[] args) //Entry point
        {
            
            Program p = new Program();
            int num;
            Console.Write("Enter a Num: ");
            num = int.Parse(Console.ReadLine());
            int res = p.Sumdigit(num); // passing value for Sumdigit function
            Console.WriteLine("Sum of digit: " + res);
        }
    }
}
