﻿using System;

namespace Table
{
    internal class Program
    {
        private void NumTable() //Function for printing table
        {
            int num, i,tablee;
            Console.WriteLine("Enter a num: ");
            num = int.Parse(Console.ReadLine());

            for (i = 1; i <= 12; i++)
            {
                tablee = num* i;
                Console.WriteLine(+ tablee);
            }  
        }
        public static void Main() // Main method
        {
            Program tab = new Program(); //
            tab.NumTable(); // Calling Function for printing table
        }







        //static void Main(string[] args)
        //{
        //    Console.WriteLine("Hello World!");
        //}
    }
}
