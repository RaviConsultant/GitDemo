﻿//using System;

//namespace Kunal_Zade_Assighn1.zip
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Hello World!");
//            Console.WriteLine("Welcome to capgi");
//        }
//    }
//}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Assighnment 1 program 1
//  program to compute sum of digits in number.
//using System;

//class sumofnum
//{
//	static int getSum(int n)
//	{
//		int sum = 0;

//		while (n != 0)
//		{
//			sum = sum + n % 10;
//			n = n / 10;
//		}

//		return sum;
//	}

//	public static void Main()
//	{
//		int n = 366354769;
//		Console.Write(getSum(n));
//	}
//}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Assighnment 1 program 2 factorial

// program to find factorial of given number
//using System;

//class Test
//{
//    
//    static int factorial(int n)
//    {
//        if (n == 0)
//            return 1;

//        return n * factorial(n - 1);
//    }

//    // Driver method
//    public static void Main()
//    {
//        int num = 10;
//        Console.WriteLine("Factorial of "
//                        + num + " is " + factorial(10));
//    }
//}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//program 3 program to print first n prime numbers
// C# program to display Prime numbers till N
//using System;

//class GFG
//{
//	static bool isPrime(int n)
//	{
//		if (n == 1 || n == 0) return false;

//		for (int i = 2; i < n; i++)
//		{
//			if (n % i == 0) return false;
//		}
//		return true;
//	}

//	public static void Main(String[] args)
//	{
//		int N = 100000000;
//		for (int i = 1; i <= N; i++)
//		{
//			if (isPrime(i))
//			{
//				Console.Write(i + " ");
//			}
//		}

//	}
//}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Program 4 Checking whether string is palindrome or not 
//using System;
//namespace palindrome
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string s, revs = "";
//            Console.WriteLine(" Enter string");
//            s = Console.ReadLine();
//            for (int i = s.Length - 1; i >= 0; i--) //String Reverse  
//            {
//                revs += s[i].ToString();
//            }
//            if (revs == s)  
//            {
//                Console.WriteLine("String is Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
//            }
//            else
//            {
//                Console.WriteLine("String is not Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
//            }
//            Console.ReadKey();
//        }
//    }
//}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Program 5 mathematical table

//using System;
//public class Exercise6
//{
//    public static void Main()
//    {
//        int j, n;

//        Console.Write("\n\n");
//        Console.Write("Display the multiplication table:\n");
//        Console.Write("-----------------------------------");
//        Console.Write("\n\n");

//        Console.Write("Input the number (Table to be calculated) : ");
//        n = Convert.ToInt32(Console.ReadLine());
//        Console.Write("\n");
//        for (j = 1; j <= 10; j++)
//        {
//            Console.Write("{0} X {1} = {2} \n", n, j, n * j);
//        }
//    }
//}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///program 6 commision
//using System;

//namespace Program6
//{
//    internal class Program
//    {
//        float Quarterly_Sales_Commission(uint sale_1, uint sale_2, uint sale_3)
//        {
//            float Total_Quarterly_Sales = sale_1 + sale_2 + sale_3;

//            float q_commission = 0;

//            if (Total_Quarterly_Sales >= 20000)
//            {
//                q_commission = Total_Quarterly_Sales * 12 / 100;
//            }
//            else if (Total_Quarterly_Sales >= 15000 && Total_Quarterly_Sales < 20000)
//            {
//                q_commission = Total_Quarterly_Sales * 10 / 100;
//            }
//            else if (Total_Quarterly_Sales >= 10000 && Total_Quarterly_Sales < 15000)
//            {
//                q_commission = Total_Quarterly_Sales * 5 / 100;
//            }
//            else
//            {
//                return q_commission;
//            }

//            return q_commission;
//        }

//        float Monthly_Sales_Commission(uint sale_1, uint sale_2, uint sale_3)
//        {
//            float Total_Monthly_Sales = sale_1 + sale_2 + sale_3;

//            float m_commission = 0;

//            if ((sale_1 >= 5000 && sale_2 >= 5000) && sale_3 >= 5000)
//            {
//                m_commission = Total_Monthly_Sales * 3 / 100;
//            }

//            return m_commission;
//        }
//        static void Main(string[] args)
//        {
//            Console.Write("1st Month Sale in USD: ");
//            uint sale_1 = uint.Parse(Console.ReadLine());
//            Console.Write("2nd Month Sale in USD: ");
//            uint sale_2 = uint.Parse(Console.ReadLine());
//            Console.Write("3rd Month Sale in USD: ");
//            uint sale_3 = uint.Parse(Console.ReadLine());

//            Program p = new Program();

//            uint Total_Quarterly_Sales = sale_1 + sale_2 + sale_3;
//            Console.WriteLine("Total Sale for the Quarter: " + Total_Quarterly_Sales + " USD");

//            Console.WriteLine("Quarterly Commission: " + p.Quarterly_Sales_Commission(sale_1, sale_2, sale_3) + " USD");

//            Console.WriteLine("Minimum Commission: " + p.Monthly_Sales_Commission(sale_1, sale_2, sale_3) + " USD");

//            float Overall_Commission = p.Quarterly_Sales_Commission(sale_1, sale_2, sale_3) + p.Monthly_Sales_Commission(sale_1, sale_2, sale_3);
//            Console.WriteLine("Overall Commission for the Quarter: " + Overall_Commission + " USD");

//        }
//    }
//}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////end assighnment 1