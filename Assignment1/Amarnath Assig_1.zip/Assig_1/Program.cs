﻿using System;

 namespace Assig_1
{

     public static void Main ( )

    //// 1st question.(sum of the digits of number)
    //    {
    //        int n, sum = 0, m; /// n is the first digit of the number and m is the second digit of number
    //        Console.Write("Enter a number: "); /// this msg will be first printed on screen to get input
    //        n = int.Parse(Console.ReadLine());
    //        while (n > 0) ///when n>0
    //        {
    //            m = n % 10; 
    //            sum = sum + m; ///this will give the sum of two digit.
    //            n = n / 10;
    //        }
    //        Console.Write("Sum is= " + sum);
    //}

    ///// 2nd question (factorial of number)
    //           {  
    //       int i, fact = 1, number;    /// initialization 
    //       Console.Write("Enter any Number: ");      /// for input
    //       number= int.Parse(Console.ReadLine());     
    //       for(i=1;i<=number;i++){      
    //       fact=fact* i;
    //}
    //       Console.Write("Factorial of " + number + " is: " + fact);     ///for output

    //    }

    //// 3rd question ( n prime number)
    //function to check if a given number is prime
    //static bool isPrime(int n)
    //{
    //    //since 0 and 1 is not prime return false.
    //    if (n == 1 || n == 0) return false;

    //    //Run a loop from 2 to n-1
    //    for (int i = 2; i < n; i++)
    //    {
    //        // if the number is divisible by i, then n is not a prime number.
    //        if (n % i == 0) return false;
    //    }
    //    //otherwise, n is prime number.
    //    return true;
    //}

    // Driver code
    //public static void Main(String[] args)
    //{
    //    int N = 100;
    //    //check for every number from 1 to N
    //    for (int i = 1; i <= N; i++)
    //    {
    //        //check if current number is prime
    //        if (isPrime(i))
    //        {
    //            Console.Write(i + " ");
    //        }
    //    }

    //}
    //// 4 check whether the given  string is palindrome or not
    //{
    //    string s, revs = "";
    //    Console.WriteLine(" Enter string");
    //    s = Console.ReadLine();
    //    for (int i = s.Length - 1; i >= 0; i--) //String Reverse  
    //    {
    //        revs += s[i].ToString();
    //    }
    //    if (revs == s) // Checking whether string is palindrome or not  
    //    {
    //        Console.WriteLine("String is Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
    //    }
    //    else
    //    {
    //        Console.WriteLine("String is not Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
    //    }
    //    Console.ReadKey();
    //}
    //// 5. write the table of the given number
    {
        int j, number; ////initialization

        Console.Write("\n\n");
        Console.Write("Display the multiplication table:\n");  ///to display the table on screen
        Console.Write("-----------------------------------");
        Console.Write("\n\n");

        Console.Write("Input the number (Table to be calculated) : ");
        number = Convert.ToInt32(Console.ReadLine());
        Console.Write("\n");
        for (j = 1; j <= 12; j++)
        {
            Console.Write("{0} X {1} = {2} \n", number, j, number * j);
        }
         

    }
}





