﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Inputno = 0;
            double factorial = 0;
            string readInput;
            bool validation = true;
            while (validation)
            {
                Console.WriteLine("Enter the number");
                readInput = Console.ReadLine();
                var isnumber = int.TryParse(readInput, out Inputno);
                if (isnumber)
                {
                    validation = false;

                    if (Inputno < 0)
                    {
                        validation = true;
                    }
                    if (Inputno > 0)
                    {
                        factorial = 1;
                    }
                }
            }
            
            while (Inputno > 1)
            {
                factorial = factorial * (Inputno);
                Inputno = Inputno - 1;
            }
              Console.WriteLine("Factorial of given number is {0}", factorial);
        }
    }
}
