﻿using System;

namespace ProgramAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //
            Program p = new Program();// creating Program object to implement class methods
            try
            {

                do // creating  an infinite loop by do while which accepts a integer variable than break
                {
                    Console.WriteLine("Please enter a number(only a positive whole number):");
                    string input = (Console.ReadLine());// reading input from command line and storing it in a string
                    int number;
                    if (int.TryParse(input, out number) && number > 0)// TryParse can work here as check for an integer value
                    {
                        Console.WriteLine("The sum of digits of {0} is {1}", input, p.sumofdigit(input));// calling sum1 
                        break;
                    }
                    else continue;
                } while (true);

                //program 2 

                //  Console.WriteLine(p.fact(5));

                //program 3

                //p.prime(10);

                //program 4

                // Console.WriteLine(p.ispal("NAMAN"));

                //program 5

                // p.tabletill12(7);

                //program 6

                //int[] month = new int[3];
                //int sum = 0;
                //for (int i = 0; i < month.Length; i++)
                //{
                //    Console.WriteLine("Month - {0} Sales in USD:", i + 1);
                //    month[i]=Convert.ToInt32(Console.ReadLine());
                //    sum+= month[i];
                //}

                //Console.WriteLine("Total Sale for the Quarter: {0}",sum);
                //Console.WriteLine("Quarterly_Commission: {0}", p.Quaterly_Com(sum));
                //Console.WriteLine("Minimum_Commission: {0}",p.Monthly_Com(month));
                //Console.WriteLine("Overall Commission for the Quarter: {0}", p.Monthly_Com(month)+Quaterly_Com(sum));

            }
            catch (Exception ex)
            {
                Console.WriteLine("Your code have been commited some Runtime-errors here:\n{0}", ex.Message);
            }
            finally { Console.ReadLine(); }

        }
        public static int Monthly_Com(int[] m)
        {
            int sum = 0;
            for (int i = 0; i < m.Length; i++)
            {
                if (m[i] >= 5000) sum += (m[i] / 100) * 3;
                else sum += 0;
            }
            return sum;

        }

        public static int Quaterly_Com(int s)
        {
            int r = s / 100;
            if (s >= 20000) return r * 12;
            else if (s >= 15000 && s < 20000) return r * 10;
            else if (s >= 10000 && s < 15000) return r * 5;
            else return 0;
        }
        /// <summary>
        /// calculating sum of digit
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        private int sumofdigit(string n)
        {
            int sum = 0;
            int n1 = Convert.ToInt32(n);
            while (n1 != 0)
            {
                sum = sum + n1 % 10;
                n1 = n1 / 10;
            }

            return sum;
        }
        /// <summary>
        /// return an integer after calculating factoring of passed number(n)
        /// </summary>
        /// <param name="f"></param>
        /// <returns></returns>
        private int fact(int fact_v)
        {
            if (fact_v == 1) return 1;
            else return fact_v * fact(fact_v - 1);
        }
        /// <summary>
        /// fuction will print prime within given range 
        /// </summary>
        /// <param name="range"></param>
        private void prime(int range)
        {
            for (int i = 1; i <= range; i++)
            {
                if (isprime(i))// return true or false
                    Console.WriteLine(i + ",");
            }

        }
        /// <summary>
        /// isprime() function will check the number is prime or not & 
        /// </summary>
        /// <param name="r"></param>
        /// <returns> return bool type </returns>
        private static bool isprime(int r)
        {
            if (r == 1 || r == 0) return false;
            for (int i = 2; i < r; i++)
            {
                if (r % i == 0) return false;
            }
            return true;
        }
        /// <summary>
        /// ispal function is for checking pallidrome of string s
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private bool ispal(string s)
        {
            string rev = "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                rev += s[i].ToString();
            }
            if (rev == s) return true;
            else return false;
        }
        /// <summary>
        /// tabletill12 will calculate table till multiple of 12 for given value
        /// </summary>
        /// <param name="r"></param>
        private void tabletill12(int r)
        {
            int sum1 = 1;
            for (int i = 1; i <= 12; i++)
            {
                sum1 = r * i;
                Console.WriteLine("{0}*{1} = {2}", r, i, sum1);

            }
        }
    }

}
