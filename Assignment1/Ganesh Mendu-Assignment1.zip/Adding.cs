﻿using System;
namespace question
{
    class Adding
    {
        /// <summary>
        /// method to calculate sum of digits of number 
        /// </summary>
        /// <param name="number"></param>
        static void digitsum(int number)
        {
            int result=0;
            while(number>0)
            {
                int digit = number % 10;
                number= number/10;
                result += digit; 
            }
            Console.WriteLine("The sum of digits of {0} is", result);

        }
        static void Main()
        {
            string input;
            int number;
            do
            {
                Console.Write("please enter a number(only a positive whole number):");
                input = Console.ReadLine();
            }
            while (!(int.TryParse(input, out number)) || number < 0);

            if(int.TryParse(input,out number) && number>0)
            {
                Adding.digitsum(number);
            }
        }
    }
}
