﻿using System;
namespace question2
{
    class Factorial
    {
        private int _number;
        public int Number { get; set; } //property sets _number with value


        /// <summary>
        /// method prints resultant factorial
        /// </summary>
        /// <param name="number"></param>
        static void PrintFactorial(int number)
        {
            int factnumber = 1;
            for (int i = 1; i <= number; i++)
            {
                factnumber *= i;
            }
            Console.WriteLine("the factorial of number is:" + factnumber);
        }
        static void Main()
        {
            Factorial f = new Factorial();

           f._number=int.Parse(Console.ReadLine());
           PrintFactorial(f._number);
           
           
        }
    }
}
