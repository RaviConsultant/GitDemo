﻿using System;
namespace question4
{
    /// <summary>
    /// method prints multicatiplication table of a number
    /// </summary>
    class MultiplicationTable
    {
        public void PrintTable(int tablenumber)
        {
            int resultantmul;
            for (int i = 1; i <= 12; i++)
            {
                resultantmul = i * tablenumber;
                Console.WriteLine("{0}*{1}={2}", i, tablenumber, resultantmul);
            }
        }
        static void Main()
        {
            MultiplicationTable t = new MultiplicationTable();
            int tablenumber=int.Parse(Console.ReadLine());
            t.PrintTable(tablenumber);
        }
    }
}
