﻿using System;
//using Capgemini.utility.hr;


namespace Program_Assignments.capg

{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////Question no 1
            //Console.WriteLine(" Enter any number:");   //taking input from user 
            //int input = Convert.ToInt32(Console.ReadLine()); //accepting input from user
            //int sum = 0;
            //while (input != 0)
            //{
            //    sum += input % 10;  //applying formula   
            //    input /= 10;
            //}
            //Console.WriteLine("The sum of digits of given number is:" + sum); //displaying final output
            //}

            //Question  no 2
            //int i, fact = 1, number;
            //Console.Write("Enter a  Number by your choice: ");
            //number = int.Parse(Console.ReadLine());
            //for (i = 1; i <= number; i++)
            //{
            //    fact = fact * i;
            //}
            //Console.Write("Factorial of " + number + " is: " + fact);

            //Question no 5
            //int i, n;
            //        Console.Write("Enter any number  : ");
            //        n = Convert.ToInt32(Console.ReadLine());
            //        Console.Write("\n");
            //        for (i = 1; i <= 12; i++)
            //        {
            //            Console.Write("{1} X {0} = {2} \n", n, i, n * i);
            //        }

            //Question no 4
            //string fstr, sestr = string.Empty;
            //Console.Write("Enter a string : ");
            //fstr = Console.ReadLine();
            //if (fstr != null)
            //{
            //    for (int i = fstr.Length - 1; i >= 0; i--)
            //    {
            //        sestr += fstr[i].ToString();
            //    }
            //    if (sestr == fstr)
            //    {
            //        Console.WriteLine("String is a Palindrome ");
            //    }
            //    else
            //    {
            //        Console.WriteLine("String is not a Palindrome  ");
            //    }
            //}
            //Console.ReadLine();

            //Question no 3
            //int num, i = 3, count, c;

            //Console.WriteLine("Please enter the number of prime numbers");
            //num = Convert.ToInt32(Console.ReadLine());

            //if (num >= 1)
            //{

            //    Console.WriteLine("First " + num + " Prime Numbers are :\n");
            //    Console.WriteLine("2");
            //}

            //for (count = 2; count <= num;)
            //{
            //    for (c = 2; c <= i - 1; c++)
            //    {
            //        if (i % c == 0)
            //            break;
            //    }
            //    if (c == i)
            //    {
            //        Console.WriteLine(i);
            //        count++;
            //    }
            //    i++;
            //}


        }
    }
}


