﻿
using System;

namespace Capgemini.Practice
{
    internal class Program
    {

        //Practice Example 1

        /// <summary>
        /// Calculating sum of digits
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        private int digitSum(int num)
        {
            int sumOfDigits = 0;
            for (; num != 0; num = num / 10)
            {
                sumOfDigits = sumOfDigits + num % 10;
            }
            return sumOfDigits;
        }




        ////Practice Example 2 
        //public int factorial(int n)
        //{
        //    int fact = 1;
        //    if (n == 0 || n == 1)
        //    {
        //        return 1;
        //    }
        //    for (int i = 2; i <= n; i++)
        //    {
        //        fact = i * fact;
        //    }
        //    return fact;
        //}





        ////Practice Problem 3
        //public bool isPrime(int a)
        //{
        //    for (int i = 2; i < a; i++)
        //    {
        //        if (a % i == 0)
        //        {
        //            return false;
        //        }
        //    }
        //    return true;
        //}
        //public void prime(int n)
        //{
        //    if (n == 1)
        //    {
        //        Console.WriteLine("No prime numbers till 1");
        //        return;
        //    }
        //    else
        //    {
        //        for (int i = 2; i <= n; i++)
        //        {
        //            if (isPrime(i))
        //            {
        //                Console.WriteLine(i + " ");
        //            }
        //        }
        //    }
        //}



        ////Practice Problem 4
        //public string palindrome(string s)
        //{
        //    char[] arr = s.ToCharArray();
        //    Array.Reverse(arr);
        //    string s1 = new string(arr);
        //    bool p = s.Equals(s1);
        //    if (p == true)
        //    {
        //        return "Yes";
        //    }
        //    else
        //    {
        //        return "No";
        //    }
        //}



        ////Practice problem 5
        //public void printTable(int n)
        //{
        //    for (int i = 1; i <= 12; i++)
        //    {
        //        Console.WriteLine(i + " * " + n + " = " + n * i);
        //    }
        //}


        //Practice problem 6
        /// <summary>
        /// Calulates overall Quaterly Commission 
        /// </summary>
        /// <param name="month1Sales"></param>
        /// <param name="month2Sales"></param>
        /// <param name="month3Sales"></param>

        //static public void overallQuatertlyCommission(int month1Sales, int month2Sales, int month3Sales)
        //{
        //    int totalQuaterlySales = month1Sales + month2Sales + month3Sales;
        //    float quatertlyCommission = 0;
        //    float minCommission = 0;
        //    float totalQuatertlyCommission ;

        //    if (totalQuaterlySales >= 20000)
        //    {
        //        quatertlyCommission = totalQuaterlySales * 12 / 100;
        //    }
        //    else if (totalQuaterlySales >= 15000 && totalQuaterlySales < 20000)
        //    {
        //        quatertlyCommission = totalQuaterlySales * 10 / 100;
        //    }
        //    else if (totalQuaterlySales >= 10000 && totalQuaterlySales < 15000)
        //    {
        //        quatertlyCommission = totalQuaterlySales * 5 / 100;
        //    }
        //    else
        //    {
        //        quatertlyCommission = 0;
        //    }

        //    if (month1Sales >= 5000 && month2Sales >= 5000 && month3Sales >= 5000)
        //    {
        //        minCommission = totalQuaterlySales * 3 / 100;
        //    }
        //    totalQuatertlyCommission = quatertlyCommission +  minCommission;

        //    Console.WriteLine("Total Sale for the Quarter: "+ totalQuaterlySales + " USD");
        //    Console.WriteLine("Quarterly_Commission: "+ quatertlyCommission+" USD");
        //    Console.WriteLine("Minimum_Commission: "+ minCommission+" USD");
        //    Console.WriteLine("Overall Commission for the Quarter: "+ totalQuatertlyCommission +" USD");

        //}


        static void Main(string[] args)
        {

            //Practice Example 1 
            //Calculate Sum of digits of the number
            int number;
            Program p = new Program();
            string input;
            do
            {
                Console.WriteLine("Please enter a number (only a positive whole number):");
                input = Console.ReadLine();

            }
            while (!(int.TryParse(input, out number)) || number < 0);
            Console.WriteLine("The sum of digits of " + input + " is " + p.digitSum(number));




            ////Practice Example 2 
            //// Calculate factorial for given number
            //int num;
            //Console.WriteLine("Enter a postive integer:");
            //num =Convert.ToInt32(Console.ReadLine());
            //if (num > 0)
            //{
            //    Console.WriteLine("The factorial of " + num + " is " +factorial(num));
            //}
            //while(num<=0)
            //{
            //    Console.WriteLine("Enter a valid number");
            //    num = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("The factorial of " + num + " is " +factorial(num)); 
            //}




            ////Practice Problem 3
            ////Print first n prime numbers
            //int num;
            //Console.WriteLine("Enter a positive integer");
            //num = Convert.ToInt32(Console.ReadLine());
            //if(num>0)
            //{
            //    Console.WriteLine("Prime numbers till " + num + " are:");
            //    prime(num);
            //}

            //while(num<=0)
            //{
            //    Console.WriteLine("Enter a Valid number");
            //    num = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("Prime numbers till "+num+" are:");
            //    prime(num);   
            //}




            ////Practice Problem 4
            ////Given String is a Palindrome 
            //Console.WriteLine("Enter a string:");
            //string s;
            //s= Console.ReadLine(); 
            //if(s!="")
            //    Console.WriteLine(palindrome(s));
            //}
            //while(s=="")
            //{
            //    Console.WriteLine("Enter a valid string:");
            //    s = Console.ReadLine();
            //    Console.WriteLine(palindrome(s));

            //}



            ////Practice problem 5
            //// Print table of n till 12
            //int num;
            //Console.WriteLine("Enter a natural number");
            //num=Convert.ToInt32(Console.ReadLine());
            //if(num>0)
            //{
            //    printTable(num);

            //}
            //while (num <= 0)
            //{
            //    Console.WriteLine("Enter a valid number");
            //    num = Convert.ToInt32(Console.ReadLine());
            //    printTable(num);
            //}



            ////Practice problem 6 
            ////Calculating Overall Commission for the Quarter 
            //int month1Sales, month2Sales, month3Sales;
            //Console.WriteLine("Month-1 Sales in USD:");
            //month1Sales = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Month-2 Sales in USD:");
            //month2Sales = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Month-3 Sales in USD:");
            //month3Sales = Convert.ToInt32(Console.ReadLine());
            //overallQuatertlyCommission(month1Sales, month2Sales, month3Sales);

        }

    }
}





