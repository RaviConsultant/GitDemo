﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    internal class Program
    {
        public int digitSum(int num)
        {
            int sumOfDigits = 0;
            for (; num != 0; num = num / 10)
            {
                sumOfDigits = sumOfDigits + num % 10;
            }
            return sumOfDigits;
        }
        static void Main(string[] args)
        {
            int number;
            Console.WriteLine("Please enter a number (only a positive whole number):");
            string input = Console.ReadLine();
            Program p = new Program();
            if (int.TryParse(input, out number) && number > 0) ;
            {
                Console.WriteLine("The sum of digits of " + input + " is " + p.digitSum(number));
            }

            while (!(int.TryParse(input, out number)) || number < 0)
            {
                Console.WriteLine("Please enter a number (only a positive whole number): ");
                input = Console.ReadLine();
                if (int.TryParse(input, out number) && number > 0)
                {
                    Console.WriteLine("The sum of digits of" + input + "is " + p.digitSum(number));
                }

            }
        }
    }
}
