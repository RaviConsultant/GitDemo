﻿using System;

namespace PremKumarAss1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Writeline("start");
        }
    }
}

//Problem statemnt-1 :- program to compute sum of digits in number.
using System;

class CalSumOfNum
{
    static int GetSum(int num)
    {
        int sum = 0;

        while (num != 0)
        {
            sum = sum + num % 10;
            num = num / 10;
        }

        return sum;
    }

    public static void Main()
    {
        int num = Convert.ToInt32(Console.ReadLine());
        Console.Write(GetSum(num));
    }
}


//Problem statemnt-2 :- program to find factorial of given number
uusing System;

namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, fact = 1, number;  //initializing 
            Console.Write("Enter any Number: ");   //taking input from user 
            number = int.Parse(Console.ReadLine());  //accepting input from user
            for (i = 1; i <= number; i++)
            {
                fact = fact * i; //formula for the factorial of numbers
            }
            Console.Write("Factorial of " + number + " is: " + fact); //displaying final output
        }
    }
}


//Problem statemnt-3 :-program to print first n prime numbers
 
using System;

namespace Assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, i = 3, count, c;

            Console.WriteLine("Enter the number of prime numbers");
            num = Convert.ToInt32(Console.ReadLine());

            if (num >= 1)
            {

                Console.WriteLine("First " + num + " Prime Numbers are :\n");
                Console.WriteLine("2");
            }

            for (count = 2; count <= num;)
            {
                for (c = 2; c <= i - 1; c++)
                {
                    if (i % c == 0)
                        break;
                }
                if (c == i)
                {
                    Console.WriteLine(i);
                    count++;
                }
                i++;
            }
        }
    }
}

//Problem statemnt-4 :- Program to verify whether string is palindrome or not 
using System;
namespace palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string s, revs = "";
            Console.WriteLine(" Enter string");
            s = Console.ReadLine();
            for (int i = s.Length - 1; i >= 0; i--) //String Reverse  
            {
                revs += s[i].ToString();
            }
            if (revs == s)
            {
                Console.WriteLine("String is Palindrome \n Entered String is {0} and reverse string is {1}", s, revs);
            }
            else
            {
                Console.WriteLine("String is not Palindrome \n Entered String is {0} and reverse string is {1}", s, revs);
            }
            Console.ReadKey();
        }
    }
}
 //Problem statemnt-5 :-Program for the mathematical table

using System;
public class Exercise6
{
    public static void Main()
    {
        int j, n;
        Console.Write("Input the number (Table to be calculated) : ");
        Console.Write("\n\n");

        n = Convert.ToInt32(Console.ReadLine());
        Console.Write("Multiplication table for{0} is \n", n);

        Console.Write("\n");
        for (j = 1; j <= 10; j++)
        {
            Console.Write("{0} X {1} = {2} \n", n, j, n * j);
        }
    }
}

 //Problem statemnt-6 :- Program For Salescommision

using System;
namespace Program6
{
    internal class Program
    {
        float Quarterly_Sales_Commission(uint sale_1, uint sale_2, uint sale_3)
        {
            float Total_Quarterly_Sales = sale_1 + sale_2 + sale_3;

            float q_commission = 0;

            if (Total_Quarterly_Sales >= 20000)
            {
                q_commission = Total_Quarterly_Sales * 12 / 100;
            }
            else if (Total_Quarterly_Sales >= 15000 && Total_Quarterly_Sales < 20000)
            {
                q_commission = Total_Quarterly_Sales * 10 / 100;
            }
            else if (Total_Quarterly_Sales >= 10000 && Total_Quarterly_Sales < 15000)
            {
                q_commission = Total_Quarterly_Sales * 5 / 100;
            }
            else
            {
                return q_commission;
            }

            return q_commission;
        }

        float Monthly_Sales_Commission(uint sale_1, uint sale_2, uint sale_3)
        {
            float Total_Monthly_Sales = sale_1 + sale_2 + sale_3;

            float m_commission = 0;

            if ((sale_1 >= 5000 && sale_2 >= 5000) && sale_3 >= 5000)
            {
                m_commission = Total_Monthly_Sales * 3 / 100;
            }

            return m_commission;
        }
        static void Main(string[] args)
        {
            Console.Write("1st Month Sale in USD: ");
            uint sale_1 = uint.Parse(Console.ReadLine());
            Console.Write("2nd Month Sale in USD: ");
            uint sale_2 = uint.Parse(Console.ReadLine());
            Console.Write("3rd Month Sale in USD: ");
            uint sale_3 = uint.Parse(Console.ReadLine());

            Program p = new Program();

            uint Total_Quarterly_Sales = sale_1 + sale_2 + sale_3;
            Console.WriteLine("Total Sale for the Quarter: " + Total_Quarterly_Sales + " USD");
            Console.WriteLine("Quarterly Commission: " + p.Quarterly_Sales_Commission(sale_1, sale_2, sale_3) + " USD");
            Console.WriteLine("Minimum Commission: " + p.Monthly_Sales_Commission(sale_1, sale_2, sale_3) + " USD");
            float Overall_Commission = p.Quarterly_Sales_Commission(sale_1, sale_2, sale_3) + p.Monthly_Sales_Commission(sale_1, sale_2, sale_3);
            Console.WriteLine("Overall Commission for the Quarter: " + Overall_Commission + " USD");

        }
    }
}
