﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignmnet3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int prime_num = 0;//Input number
            int count = 1;
            int temp, i;
            bool validation = true;
            while (validation)
            {
                string readInput;
                Console.WriteLine("Enter the number");
                readInput = Console.ReadLine();
                var isvalid = int.TryParse(readInput, out prime_num);
                if (isvalid)
                {
                    validation = false;
                    if (prime_num< 0)
                    {
                        validation = true;
                    }
                }
            }



            Console.WriteLine("The prime numbers under {0} are", prime_num);
            while (count < prime_num)
            {
                count++;
                temp = 0;
                for (i = 2; i <= (count / 2); i++)
                {
                    if (count % i == 0)
                    {
                        temp = 1;
                        break;
                    }
                }
                if (temp == 0)
                {
                    Console.Write("{0} , ", count);

                }
            }
        }
    }
}
