﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string stringInput;
            int stringLen;

            Console.WriteLine("Input a string");
            stringInput = Console.ReadLine();
            stringLen = stringInput.Length;

            int counter = 0;
            for (int i = 1; i <= stringLen / 2; i++)
            {

                if (stringInput[i - 1] != stringInput[stringLen - i])
                {
                    Console.WriteLine("{0} is not a palindrome", stringInput);
                    counter = 1;
                    break;
                }

            }
            if (counter == 0)
            {
                Console.WriteLine("{0} is a palindrome", stringInput);
            }
        }
    }
}
