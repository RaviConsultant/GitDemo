﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Inputint = 0;

            bool validation = true;
            int i;
            while (validation)
            {
                string readInput;
                Console.WriteLine("Enter the number");
                readInput = Console.ReadLine();
                var isvalid = int.TryParse(readInput, out Inputint);
                if (isvalid)
                {
                    validation = false;
                    if (Inputint < 0)
                    {
                        validation = true;
                    }
                }

            }
          
            for (i = 1; i <= 12; i++)
            {
                Console.WriteLine("{0}\t*\t{1}\t=\t{2}", i, Inputint, i * Inputint);
            }
        }
    }
}
