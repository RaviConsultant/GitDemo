﻿//Practice Example 2
//Write a program to print first n prime numbers
using System;

namespace primenumber
{
    class Program
    {
        // entery point or main method
        static void Main(string[] args)
        {
            int i, number, primeCount;
            try
            {
                Console.Write("enter any positive whole number :");
                // take input fron user
                int givenumber = int.Parse(Console.ReadLine());

                //Console.WriteLine("all prime number between 1 and " + givenumber + " is :");
                if (givenumber < 2)
                {
                    Console.WriteLine("please enter valid number");
                }

                else
                {
                    for (number = 1; number <= givenumber; number++)
                    {
                        primeCount = 0;
                        for (i = 2; i <= number / 2; i++)
                        {
                            if (number % i == 0)
                            {
                                primeCount++;
                                break;
                            }
                        }
                        if (primeCount == 0 && number != 1)
                            Console.WriteLine(number);
                    }
                }
            }
            // exception handling for invald formet
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}