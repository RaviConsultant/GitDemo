﻿//Program no.1 Sum of Digits of a Number

/*
using System;

namespace SumOfDigits
{
    public class SOD
    {
        public int SumOfDigits(int Digits)
        {
            int sum = 0;
            while (Digits > 0)
            {
                sum = sum + (Digits % 10);
                Digits = Digits / 10;
            }

            return sum;
        }
    }
}

*/




//Program no.2   Find Factorial of a Number

 /*   
    
using System;

namespace Capgemini
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number");
            int input = Convert.ToInt32(Console.ReadLine());
            int fact = 1;
            for (int i = 1; i <= input; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("Factorial of the number is : " + fact);
        }
    }

}
*/


/*
// Program no.3   Print first N prime numbers

using System;

namespace Capgemini
{
    internal class Program
    {

        public bool IsPrime(int inp)  //Creating a object
        {

           int i;
           int a = 0;

            for (i = 2; (i*i) <= inp; i++)
            {
                if ((inp % i) == 0)
                {
                   
                    a = 1;
                   
                    return false;

                    
                }
            }

            if (a == 0)
            {
                return true; ;
            }
            return false;
          
        }


        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number(Positive) ");
            int input = Convert.ToInt32(Console.ReadLine());
            int i;
            Program prime = new Program();
         
             for (i = 2; i < input; i++)
             {
               
                if (prime.IsPrime(i))
                 {
                     Console.WriteLine(i);
                    
                 }
                

             }
            



        }
    }
}
  

*/





// Program no. 4 Check whether given string is Pailondrome or not

/*
using System;

namespace Capgemini
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the String");
            string str = Console.ReadLine();
            string revstr = "";
            str = str.ToLower();  //Lower Casing the string 
            for (int i = str.Length - 1; i >= 0; i--)
            {
                revstr = revstr + str[i];
            }
            if (revstr == str)
            {
                Console.WriteLine("Yes");
            }
            else {
                Console.WriteLine("No");
                    }

        }

    }
}

*/

// Program no.5  Program to print mathematical table of given number till 12

/*
 * 
 * using System;

namespace Capgemini
{
    internal class Program
    {

        
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number");
            int input = Convert.ToInt32(Console.ReadLine());
            int table = 0;
            
            for (int i = 1; i <= 12; i++)
            {
                table = input * i;
                Console.Write("{0} * {1} = ",i,input);
                Console.WriteLine(table);

            }
            
        }
    }

}

*/

//Program no.6 Find Overall Commission for the Quarter

/*
using System;

namespace Capgemini
{
    internal class Program
    {

        public int commision(int a, int b)
        {
            int margin = 0;
            margin = (a * b) / 100;
            return margin;
        }

        public static void Main(string[] args)
        {
            Console.Write("Month-1 Sales in USD: ");
            int month1sales = Convert.ToInt32(Console.ReadLine());
           
            Console.Write("Month-2 Sales in USD: ");
            int month2sales = Convert.ToInt32(Console.ReadLine());
           
            Console.Write("Month-3 Sales in USD: ");
            int month3sales = Convert.ToInt32(Console.ReadLine());
           
            int totalsales = month3sales + month1sales + month2sales;
            Console.WriteLine("Total Sale for the Quarter: {0} USD", totalsales);

           
            
            int quarterlycommision = 0; 
            Program xyz = new Program();
            
            if (totalsales >= 20000)
            {
                quarterlycommision = xyz.commision(12, totalsales);
            }

           else if (totalsales>= 15000 && totalsales < 20000)
            {
                quarterlycommision = xyz.commision(10, totalsales);
            }
           else if (totalsales >= 10000 && totalsales<15000)
            {
                quarterlycommision = xyz.commision(5, totalsales);
            }
            else
            {
                quarterlycommision = 0 ;
            }


            int mincommision=0 ;
            mincommision= xyz.commision(3, totalsales);
            Console.WriteLine("Quarterly_Commission: {0} USD", quarterlycommision);
            Console.WriteLine("Monthly_Commission: {0} USD", mincommision);

            int totalcommision = 0 ;
            totalcommision = quarterlycommision + mincommision;
            Console.WriteLine("Overall Commission for the Quarter: {0} USD",totalcommision);



        }
    }

}

*/