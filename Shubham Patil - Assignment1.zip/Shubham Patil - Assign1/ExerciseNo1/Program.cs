﻿using System;

namespace ExerciseNo1{
    internal class Program{
        // Function to get sum of numbers
        // Sum number will also be a uint. So return type is uint. 
        uint gettingSum(uint number){
            // start sum of digits after each iteration 
            uint sum = 0; 
            while (number != 0){
                sum = sum + number % 10;
                number = number / 10;
            }
            return sum;
        }
        static void Main(string[] args){
            // the Try - Catch Block untill suitable input is provided 
            Again:
            try{
                // user input
                Console.Write("Please enter a number(only a positive whole number): ");
                // value of 'uint' datatype is used because only positive whole number is the desired input 
                uint number = uint.Parse(Console.ReadLine());

                Program p = new Program();

                // output
                Console.WriteLine("The sum of digits of  " + number + " is " + p.gettingSum(number));
            }
            catch{
                goto Again;
            }
        }
    }
}
