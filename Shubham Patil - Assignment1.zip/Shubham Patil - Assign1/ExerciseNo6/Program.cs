﻿using System;

namespace ExerciseNo6{
    internal class Program{
        // Function to calculate Quarterly Sales Commission
        // Calculated commission can be a float value even if sales are of uint datatype. So, the return type is taken as float 
        float QuarterlySalesCommission(uint sale_1, uint sale_2, uint sale_3){
            float TotalQuarterlySales = sale_1 + sale_2 + sale_3;
            float q_commission = 0;

            if (TotalQuarterlySales >= 20000){
                q_commission = TotalQuarterlySales * 12 / 100;
            }
            else if (TotalQuarterlySales >= 15000 && TotalQuarterlySales < 20000){
                q_commission = TotalQuarterlySales * 10 / 100;
            }
            else if (TotalQuarterlySales >= 10000 && TotalQuarterlySales < 15000){
                q_commission = TotalQuarterlySales * 5 / 100;
            }
            else{
                return q_commission;
            }
            return q_commission;
        }

        // Function to calculate Monthly Sales Commission
        // Calculated commission can be a float value even if sales are of uint datatype. So, the return type is taken as float
        float MonthlySalesCommission(uint sale_1, uint sale_2, uint sale_3){
            float TotalMonthlySales = sale_1 + sale_2 + sale_3;

            float m_commission = 0;

            if ((sale_1 >= 5000 && sale_2 >= 5000) && sale_3 >= 5000){
                m_commission = TotalMonthlySales * 3 / 100;
            }

            return m_commission;
        }
        static void Main(string[] args){
            // user input
            Console.Write("1st Month Sale in USD: ");
            uint sale_1 = uint.Parse(Console.ReadLine());
            Console.Write("2nd Month Sale in USD: ");
            uint sale_2 = uint.Parse(Console.ReadLine());
            Console.Write("3rd Month Sale in USD: ");
            uint sale_3 = uint.Parse(Console.ReadLine());

            Program p = new Program();

            // Output Statements
            uint TotalQuarterlySales = sale_1 + sale_2 + sale_3;
            Console.WriteLine("Total Sale for the Quarter: " + TotalQuarterlySales + " USD");
            Console.WriteLine("Quarterly Commission: " + p.QuarterlySalesCommission(sale_1, sale_2, sale_3) + " USD");
            Console.WriteLine("Minimum Commission: " + p.MonthlySalesCommission(sale_1, sale_2, sale_3) + " USD");
            float Overall_Commission = p.QuarterlySalesCommission(sale_1, sale_2, sale_3) + p.MonthlySalesCommission(sale_1, sale_2, sale_3);
            Console.WriteLine("Overall Commission for the Quarter: " + Overall_Commission + " USD");
        }
    }
}
