﻿using System;

namespace ExerciseNo5{
    internal class Program{
        static void Main(string[] args){
            int i, num;
            Console.Write("Enter a number :");
            num = int.Parse(Console.ReadLine());
            for (i = 1; i <= 10; i++)
            {
                Console.Write("{0} X {1} = {2} \n", num, i, num * i);

            }
            Console.ReadLine();
        }
    }
}
