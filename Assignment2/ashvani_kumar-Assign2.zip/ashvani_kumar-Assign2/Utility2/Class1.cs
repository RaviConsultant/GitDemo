﻿using System;

namespace OOP.Utility2
{
    public class Calculate
    {/// <summary>
     /// calculating Monthly commision 
     /// </summary>
     /// <param name="m">months</param>
     /// <param name="s">sum of values</param>
     /// <returns>float</returns>
        public float Monthly_Com(int[] m, int s)
        {

            float sum = 0;

            if (m[0] >= 12000 && m[1] >= 12000 && m[2] >= 12000) sum += (s / 100) * 2.45f;
            else if (m[0] >= 7500 && m[1] >= 7500 && m[2] >= 7500) sum += (s / 100) * 1.25f;
            else sum += 0;
            return sum;

        }
        /// <summary>
        /// Quaterly_Com() calculates Quaterly based commision 
        /// </summary>
        /// <param name="s">sum of values</param>
        /// <returns>float</returns>
        public float Quaterly_Com(int s)
        {
            float r = s / 100;
            if (s >= 50000) return r * 5.0f;
            else if (s >= 30000) return r * 4.5f;
            else if (s >= 20000) return r * 3.75f;
            else if (s >= 15000) return r * 2.5f;
            else if (s >= 10000) return r * 1.75f;

            else return 0;
        }
    }
}
