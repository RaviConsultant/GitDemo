﻿using System;
using IBank.Utility;

namespace IBank.Design1
{
    internal class Program
    {

        internal abstract class Account
        {
            public int AccNumber;
            public IBank.Utility.Customer customer;
            public IBank.Utility.Branch branch;
            public double CurrentBalance;
            public abstract void OpenAccount();
            public void Deposit(double Amount) { CurrentBalance += Amount; }
            public void CloseAccount() { CurrentBalance = 0.00; }
        }

        public class SB_Account : Account
        {
            public override void OpenAccount() { CurrentBalance = 100.00; }
            public void Withdraw(double Amount)
            {
                if (Amount <= 75.00) { CurrentBalance -= Amount; }
                else { Console.WriteLine("Withdraw Limit 75 USD"); }
            }
        }

        public class Current_account: Account
        {
            public override void OpenAccount() { CurrentBalance = 500.00; }
            public void Withdraw(double Amount)
            {
                if (Amount <= 400.00) { CurrentBalance -= Amount; }
                else { Console.WriteLine("Withdraw Limit 75 USD"); }
            }
        }

        public class FD_Account: Account
        {
            public override void OpenAccount() { throw new NotImplementedException(); }
        }

        public class RD_Account: Account
        {
            public override void OpenAccount() { throw new NotImplementedException(); }
        }
        static void Main(string[] args)
        {
            SB_Account A = new SB_Account();
            A.AccNumber = 100010;
            A.customer.FirstName = "Eren";
            A.customer.LastName = "Yeager";
            A.customer.ContactInfo.Phone = 9998887770;
            A.OpenAccount();

            Console.WriteLine("Hello World!");
        }
    }
}
