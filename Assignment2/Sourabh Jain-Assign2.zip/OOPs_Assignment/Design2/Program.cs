﻿using System;
using Utility;
using Design1;

namespace Design2
{
    internal class Program
    {
        internal class Account
        {
            public int AccNumber;
            public Utility Customer customer;
            public Utility Utility.Branch branch;
            public double CurrentBalance;
        }
        internal abstract class IAccount : Account
        {
            public abstract void Open_Account();
            public void Deposit(int Amount) { currBal += Amount; }
            public void Close_Account() { currBal = 0.00; }
        }

        public class SBAccount : IAccount
        {
            public override void Open_Account() { CurrentBalance = amt; }
            public void Withdraw(double Amount)
            {
                if (Amount <= 75.00) { CurrentBalance -= amt; }
                else { Console.WriteLine("Withdraw Limit 75 USD"); }
            }
        }

        public class Current_account : IAccount
        {
            public override void Open_Account() { CurrentBalance = 500.00; }
            public void Withdraw(double Amount)
            {
                if (Amount <= 400.00) { CurrentBalance -= Amount; }
                else { Console.WriteLine("Withdraw Limit 75 USD"); }
            }
        }

        public class FDAccount : IAccount
        {
            public override void Open_Account() { throw new NotImplementedException(); }
        }

        public class RD_Account : IAccount
        {
            public override void Open_Account() { throw new NotImplementedException(); }
        }
        static void Main(string[] args)
        {
            
        }
    }
}