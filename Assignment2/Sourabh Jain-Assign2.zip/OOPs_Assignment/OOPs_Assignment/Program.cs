﻿using System;


namespace OOPs_Assignment
{
    internal class Program
    {
        abstract class Account
        {
            public int Accountnum;
            public string name;
            public string branch = "Indore, 452001";
            public int currentBalance;
            public string city;
            public string zip;


            public abstract void Open_Account();

            
            public virtual void Close_Account()
            {
                currentBalance = 0;
            }
        }

        class SbAccount : Account
        {
            public override void Open_Account()
            {
                Random rn = new Random();
                Accountnum = rn.Next();
                Console.WriteLine("Enter name");
                name = Console.ReadLine();
                Console.WriteLine("Enter Address:");
                Console.WriteLine("enter city");

                city = Console.ReadLine();
                Console.WriteLine("enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("Enter amount:");
                int amt = int.Parse(Console.ReadLine());
                if (amt >= 75)
                {

                    currentBalance = amt;
                    Console.WriteLine("account opened Successfully");
                    Console.WriteLine(name + " from " + city + " " + zip + " " + "Your Accountno is :" + Accountnum);
                }
                else
                {
                    Console.WriteLine("Please deposit atleat 75$");
                }
            }
            public void Deposit(int amount)
            {
                    string j;
                    Console.WriteLine("please enter account Number");
                    j= Console.ReadLine();
                    Console.WriteLine("please enter amount");
                    amount=int.Parse(Console.ReadLine());
                    currentBalance += amount;

                }
            void  Withdraw(int amount)
                {
                    string j;
                    Console.WriteLine("please enter account Number");
                    j = Console.ReadLine();
                    Console.WriteLine("please enter amount");
                    amount = int.Parse(Console.ReadLine());
                    currentBalance -= amount;

                }
            
        }
        class CurrentAccount : Account
        {
        public override void Open_Account()
        {
            Random rn = new Random();
            Accountnum = rn.Next();
            Console.WriteLine("Enter name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Address:");

            Console.WriteLine("enter city");

            city = Console.ReadLine();
            Console.WriteLine("enter zip");
            zip = Console.ReadLine();
            Console.WriteLine("Enter amount:");
            int amt = int.Parse(Console.ReadLine());
            if (amt >= 500)
            {
                currentBalance = amt;
                Console.WriteLine("account opened Successfully");
                Console.WriteLine(name + " from " + city + " " + zip + " " + "Your Accountno is :" + Accountnum);
                }
            else
            {
                Console.WriteLine("Please deposit atleat 400$");
            }
        }
                public void Deposit(int amount)
                {
                    string j;
                    Console.WriteLine("please enter account Number");
                    j = Console.ReadLine();
                    Console.WriteLine("please enter amount");
                    amount = int.Parse(Console.ReadLine());
                    currentBalance += amount;

                }
                public void Withdraw(int amount)
                {
                    string j;
                    Console.WriteLine("please enter account Number");
                    j = Console.ReadLine();
                    Console.WriteLine("please enter amount");
                    amount = int.Parse(Console.ReadLine());
                    currentBalance -= amount;


                }
        }


        class FDAccount : Account
        {
            public override void Open_Account()
            {
                Random rn = new Random();
                Accountnum = rn.Next();
                Console.WriteLine("Enter name");
                name = Console.ReadLine();
                Console.WriteLine("Enter Address:");
                Console.WriteLine("enter city");

                city = Console.ReadLine();
                Console.WriteLine("enter zip");
                zip = Console.ReadLine();

                Console.WriteLine("Enter amount:");
                int amt = int.Parse(Console.ReadLine());
                currentBalance = amt;
                Console.WriteLine("Account successfully opened");
                Console.WriteLine(name + " from " + city + " " + zip + " " + "Your Accountno is :" + Accountnum);

            }
        }

        class RDAccount : Account
        {
            public override void Open_Account()
            {

                Random rn = new Random();
                Accountnum = rn.Next();
                Console.WriteLine("Enter name");
                name = Console.ReadLine();
                Console.WriteLine("Enter Address:");
                Console.WriteLine("enter city");

                city = Console.ReadLine();
                Console.WriteLine("enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("Enter amount:");
                int amt = int.Parse(Console.ReadLine());
                currentBalance = amt;
                Console.WriteLine("Account successfully opened");
                Console.WriteLine(name+" from " + city+" "+zip+" "+"Your Accountno is :" + Accountnum);
            }
        }

        



        public static void Main(string[] args)
        {
            string i;
            Program P = new Program();
            Console.WriteLine("Press 1 to open Account");
            Console.WriteLine("Press 2 to Deposit");
            Console.WriteLine("Press 3 to Withdraw");
            Console.WriteLine("Press 4 to Close Account");
            string input = Console.ReadLine();

            if (input == "1")
            {
                Console.WriteLine("Press 1 to open saving account");
                Console.WriteLine("Press 2 to open Current account");
                Console.WriteLine("Press 3 to open FD account");
                Console.WriteLine("Press 4 to open RD account");
                i = Console.ReadLine();
                if (i == "1")
                {
                    SbAccount sa = new SbAccount();
                    sa.Open_Account();
                   
                }
                else if (i == "2")
                {
                    CurrentAccount ca = new CurrentAccount();
                    ca.Open_Account();
                }
                else if (i == "3")
                {
                    FDAccount fa = new FDAccount();
                    fa.Open_Account();

                }
                else if (i == "4")
                {
                    RDAccount ra = new RDAccount();
                    ra.Open_Account();
                }
                else
                {
                    Console.WriteLine("wrong input");
                }
            }
            else if(input == "2")
            {
                    string a;
                    Console.WriteLine("Press 1 to deposit in saving Acoount" +
                        "\n press 2 to deposit in Current Account");
                    a= Console.ReadLine();
                    if (a == "1")
                    {
                    SbAccount sb = new SbAccount();
                    //sb.Deposit();
                }
                    else if(a == "2")
                    {
                    CurrentAccount c = new CurrentAccount();
                    //c.Withdraw();
                }

            }
            else if (input == "3")
            {
                string b;
                Console.WriteLine("Press 1 to Withdraw in saving Acoount" +
                        "\n press 2 to withdraw in Current Account");
                b= Console.ReadLine();
                if(b == "1")
                {
                    SbAccount sb= new SbAccount();
                    //sb.Withdraw();
                }
                else if(b == "2")
                {
                    CurrentAccount c=new CurrentAccount();
                    //c.Withdraw();
                }


            }
            else if (input == "4")
            {
                Console.WriteLine("Account Closed");
            }

        }
    }
}