﻿using System;
using IBankManagememt.Utility;

namespace IBankManagememt.Design2
{
    internal class Program
    {
        public class Account
        {

            public string AccNo;
            Customer customer;
            Branch branch;
            public double CurrentBalance;

        }
        public interface IAccount
        {
            public void OpenAccount();
            public void Deposit();
            public void CloseAccount();
        }

        public class SBAccount : Account, IAccount
        {
            
            
            public void OpenAccount()
            {
                string name, city, zip;
                int amount;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter city");
                city = Console.ReadLine();
                Console.WriteLine("Enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("enter Amount");
                amount = int.Parse(Console.ReadLine());
                if (amount >= 100)
                {
                    Random random = new Random();
                    int r=random.Next();
                    Console.WriteLine("Hello " + name + " from " + city + "," + zip );
                    Console.WriteLine("Account Opened \n Your account no is : " + r + "  amount  =" + amount);
                }
                else
                {
                    Console.WriteLine("To open account please deposit 100 USD");
                }
                //program created by SourabhJain

            }
            public void Deposit() {
                int amount;
                int accountno;
                Console.WriteLine("Enter account NO");
                accountno=int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Amount");
                amount=int.Parse(Console.ReadLine());
                Console.WriteLine("USD" + amount + "is deposited in account no" + accountno);
            }
            public void CloseAccount() { 
                string name, accountno;
                Console.WriteLine("Enter Name");
                name= Console.ReadLine();
                Console.WriteLine("Enter Account no");
                accountno= Console.ReadLine();
                Console.WriteLine("Account Closed");
                Console.WriteLine("Account Closed"); }

            public void Withdraw()
            {
                Console.WriteLine("Please Emter Accountno");
                string accountno=Console.ReadLine();
                Console.WriteLine("Please enter amount");
                int aamount=int.Parse(Console.ReadLine());
                if (aamount > 75)
                {
                    Console.WriteLine("Withdraw limit is 75 USD/trans");
                }
                else if (CurrentBalance - aamount > 100)
                {
                    CurrentBalance = CurrentBalance - aamount;
                    Console.WriteLine( "Current Balance is " + CurrentBalance);

                }
                else
                {
                     Console.WriteLine("We need to maintain a minimum balance of 100 USD");
                }
            }

        }
        public class CurrentAccount : Account, IAccount
        {
            public void OpenAccount()
            {
                string name, city, zip;
                int amount;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter city");
                city = Console.ReadLine();
                Console.WriteLine("Enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("enter Amount");
                amount = int.Parse(Console.ReadLine());
                if (amount >= 500)
                {
                    Random random = new Random();
                    int r = random.Next();
                    Console.WriteLine("Hello " + name + " from " + city + "," + zip );
                    Console.WriteLine("Account Opened \n Your account no is : " + r + "  amount="+amount);
                }
                else
                {
                    Console.WriteLine("Please deposit atleast 500 usd");
                }
            }//program created by SourabhJain
            public void Deposit() {
                int amount;
                int accountno;
                Console.WriteLine("Enter account NO");
                accountno = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Amount");
                amount = int.Parse(Console.ReadLine());
                Console.WriteLine("USD" + amount + "is deposited in account no" + accountno);
            }
            public void CloseAccount() {
                string name, accountno;
                Console.WriteLine("Enter Name");
                name= Console.ReadLine();
                Console.WriteLine("Enter Account no");
                accountno= Console.ReadLine();
                Console.WriteLine("Account Closed"); }
            public void Withdraw()
            {
                Console.WriteLine("Please Emter Accountno");
                string accountno = Console.ReadLine();
                Console.WriteLine("Please enter amount");
                int aamount = int.Parse(Console.ReadLine());
                if (aamount > 400)
                {
                     Console.WriteLine("Withdraw limit is 75 USD/trans");
                }
                else if (CurrentBalance - aamount > 500)
                {
                    CurrentBalance = CurrentBalance - aamount;
                    Console.WriteLine("Current Balance is " + CurrentBalance);


                }
                else
                {
                    Console.WriteLine( "We need to maintain a minimum balance of 500 USD");
                }
            }

        }
        public class FixedDepositAccount : Account, IAccount
        {
            public void OpenAccount() {
                string name, city, zip;
                int amount;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter city");
                city = Console.ReadLine();
                Console.WriteLine("Enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("enter Amount");
                amount = int.Parse(Console.ReadLine());
                Random random = new Random();
                int r = random.Next();
                Console.WriteLine("Hello " + name + " from " + city + "," + zip );
                Console.WriteLine("Account Opened \n Your account no is : " + r + "amount" + amount);
            }
            public void Deposit() {
                int amount;
                int accountno;
                Console.WriteLine("Enter account NO");
                accountno = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Amount");
                amount = int.Parse(Console.ReadLine());
                Console.WriteLine("USD" + amount + "is deposited in account no" + accountno);
            }
            public void CloseAccount() {
                string name, accountno;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter Account no");
                accountno = Console.ReadLine();
                Console.WriteLine("Account Closed");
                Console.WriteLine("Account Closed");
            }

        }
        public class ReccuringDepositAccount : Account, IAccount
        {
            public void OpenAccount() {
                string name, city, zip;
                int amount;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter city");
                city = Console.ReadLine();
                Console.WriteLine("Enter zip");
                zip = Console.ReadLine();
                Console.WriteLine("enter Amount");
                amount = int.Parse(Console.ReadLine());
                Random random = new Random();
                int r = random.Next();
                Console.WriteLine("Hello " + name + " from " + city + "," + zip);
                Console.WriteLine("Account Opened \n Your account no is : " + r + "amount" + amount);
            }
            public void Deposit() {
                int amount;
                int accountno;
                Console.WriteLine("Enter account NO");
                accountno = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Amount");
                amount = int.Parse(Console.ReadLine());
                Console.WriteLine("USD" + amount + "is deposited in account no" + accountno);
            }
            public void CloseAccount() {
                string name, accountno;
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                Console.WriteLine("Enter Account no");
                accountno = Console.ReadLine();
                Console.WriteLine("Account Closed");
                Console.WriteLine("Account Closed");
            }

        }
        static void Main(string[] args)
        {
            string input;
            string i;
            string j;
            string m;
            Console.WriteLine("Press 1 to Open Account" +
                "\n Press 2 to Deposit " + "\n Press 3 to Withdraw" + "\n Press 4 to Close Account");
            input = Console.ReadLine();
            if(input == "1")               //toOpenAccount
            {
                Console.WriteLine("Press 1 to Open SbAccount" +"\n Press 2 to Open Current Account " + 
                    "\n Press 3 to Open FD Account" + "\n Press 4 to Open RD Account");
                i = Console.ReadLine();
                if (i == "1")
                {
                    SBAccount sa = new SBAccount();
                    sa.OpenAccount();
                }
                else if (i == "2")
                {
                    CurrentAccount ca = new CurrentAccount();
                    ca.OpenAccount();
                }
                else if (i == "3")
                {
                    FixedDepositAccount fa = new FixedDepositAccount();
                    fa.OpenAccount();
                }
                else if (i == "4")
                {
                    ReccuringDepositAccount ra = new ReccuringDepositAccount();
                    ra.OpenAccount();
                }
            }
            else if(input == "2")
            {
                Console.WriteLine("Press 1 to Deposit in saving Account"+"\n Press 2 to deposit in Current Account"+
                    "\nPress 3 to deposit in FD Account"+"\npress 4 to deposit in RD Account");
                j= Console.ReadLine();
                if (j == "1")
                {
                    SBAccount sa = new SBAccount();
                    sa.Deposit();
                }
                else if (j == "2")
                {
                    CurrentAccount ca = new CurrentAccount();
                    ca.Deposit();
                }
                else if (j == "3")
                {
                    FixedDepositAccount fa = new FixedDepositAccount();
                    fa.Deposit();
                }
                else if (j == "4")
                {
                    ReccuringDepositAccount ra = new ReccuringDepositAccount();
                    ra.Deposit();
                }

            }
            else if (input == "3")
            {
                Console.WriteLine("Press 1 to Withdran from saving Account" + "\n Press 2 to Withdraw from Current Account");
                m= Console.ReadLine();
                if (m == "1")
                {
                    SBAccount sa = new SBAccount();
                    sa.Withdraw();
                }
                else if (m == "2")
                {
                    CurrentAccount ca = new CurrentAccount();
                    ca.Withdraw();
                    
                }
            }
            else if (input == "4")
            {
                Console.WriteLine("Press 1 to close Account" + "\n Press 2 to close Current Account" +
                    "\nPress 3 to close FD Account" + "\npress 4 to Close RD Account");
                j=Console.ReadLine();
                if (j == "1")
                {
                    SBAccount sa = new SBAccount();
                    sa.CloseAccount();
                }
                else if (j == "2")
                {
                    CurrentAccount ca = new CurrentAccount();
                    ca.CloseAccount();
                }
                else if (j == "3")
                {
                    FixedDepositAccount fa = new FixedDepositAccount();
                    fa.CloseAccount();
                }
                else if (j == "4")
                {
                    ReccuringDepositAccount ra = new ReccuringDepositAccount();
                    ra.CloseAccount();
                }
            }


        }
    }//program created by SourabhJain

}
