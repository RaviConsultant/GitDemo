﻿using System;

namespace Ford.Utility
{
    public class Class1
    {
    }
}
