﻿using System;
using OOP.Utility2;

namespace OOP.CommissionS
{
    internal class Program
    {/// <summary>
     /// creating structure for Month with array to store values into
     /// </summary>
        public struct Month
        {
            public int[] mon;

        };
        static void Main(string[] args)
        {

            Month month = new Month();
            month.mon = new int[3];

            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Month - {0} Sales in USD:", i + 1);
                month.mon[i] = Convert.ToInt32(Console.ReadLine());
                sum += month.mon[i];
            }
            Calculate c = new Calculate();

            Console.WriteLine("Total Sale for the Quarter: {0}", sum);
            Console.WriteLine("Quarterly_Commission: {0}", c.Quaterly_Com(sum));
            Console.WriteLine("Minimum_Commission: {0}", c.Monthly_Com(month.mon, sum));
            Console.WriteLine("Overall Commission for the Quarter: {0}", c.Monthly_Com(month.mon, sum) + c.Quaterly_Com(sum));
        }
    }
}
